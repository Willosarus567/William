SELECT * FROM cats WHERE age=4; 

SELECT * FROM cats WHERE name="Egg";    /*Remember this is name VARCHAR is case insensitive.
                                          You could put anything in the string that spells "eGG"
                                          and it would work.*/



