SELECT cat_id FROM cats; 

SELECT * FROM cats WHERE cat_id>=1;

SELECT name, breed FROM cats;

SELECT * FROM cats WHERE age >= 4 AND breed = 'Tabby';

SELECT cat_id, age FROM cats WHERE cat_id = age; /*If both values are integers they can be 
                                                    set equal to each other.*/

