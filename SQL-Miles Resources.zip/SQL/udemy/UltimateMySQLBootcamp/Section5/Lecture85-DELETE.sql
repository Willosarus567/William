DELETE FROM cats WHERE name='Egg';

DELETE FROM cats WHERE age = 4;

DELETE FROM cats WHERE age = cat_id;

DELETE FROM cats WHERE cat_id > 1; 

DELETE FROM cats; /*This is the simpliest way to delete all data from any table, in this case its table cats.*/