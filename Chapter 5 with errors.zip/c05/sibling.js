// Select the starting point and find its siblings
var startItem = document.getElementsById('two');
var prevItem = startItem.previousSibling;
var nextItem = startItem.nextSibling; 

// Change the values of the siblings' class attributes 
prevItemm.className = 'complete';
nextItem.className = 'cool';  