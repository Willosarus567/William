var removeEl = document.getElementsByTagName(li')[3];     

var containerEl = removeEl.parentNode;                   //Its containing element

containerEl.removeChild(removeEl);                       //Removing the element 

